// StarterSat4j.java
import org.sat4j.minisat.SolverFactory;
import org.sat4j.specs.ISolver;
import org.sat4j.core.VecInt;
import org.sat4j.specs.IVecInt;
import org.sat4j.specs.ContradictionException;
import org.sat4j.specs.TimeoutException;

public class SudokuSolver {

    // creates a sat instance using the given sudoku puzzle, solves that instance, 
    // then uses the solution to construct and return a solved puzzle
    // returns null if the puzzle cannot be solved
    public static Sudoku solveSudoku(Sudoku sudo){
        ISolver solver = buildSolver(sudo);
        int size = sudo.getBoard().length;
        int[][] solved = new int[size][size];
        try{
            boolean isSat = solver.isSatisfiable();
            if(isSat){
                int[] model = solver.model();
                for(int varNumber : model){
                    if(varNumber > 0){
                        setIndexByVarnumber(solved, varNumber);
                    }
                }
            }
        } catch (TimeoutException te) {
            System.out.println("Solving timed out: " + te.getMessage());
        }
        return new Sudoku(solved);
    }

    private static ISolver buildSolver(Sudoku sudo){
        //TODO
        ISolver solver = SolverFactory.newDefault();
        solver.setTimeout(5);
        int[][] board = sudo.getBoard();
        int boardSize = board.length;
        int n = (int) Math.sqrt(boardSize);

        
        return solver;
    }

    private static int getVarNumber(int row, int col, int val, int boardSize){
        int num = (row)*boardSize*boardSize + (col)*boardSize + val;
        return num;
    }

    private static void setIndexByVarnumber(int[][] board, int varNumber){
        int boardSize = board.length;
        int row = (varNumber-1) / (boardSize*boardSize);
        varNumber -= row*boardSize*boardSize;
        int col = (varNumber-1) / boardSize;
        varNumber -= col*boardSize;
        int val = varNumber;
        board[row][col] = val;
    }

    private static void addExactlyOneOfClauses(int[] vars, ISolver solver){
;        try{
            solver.addClause(new VecInt(vars));
            for(int i = 0; i < vars.length; i++){
                for(int j = i+1; j < vars.length; j++){
                    solver.addClause(new VecInt(new int[] {-vars[i], -vars[j]}));
                }
            }
        } catch (ContradictionException ce) {
            // thrown if the formula becomes trivially unsatisfiable while adding clauses
            System.out.println("Formula is trivially unsatisfiable during construction: " + ce.getMessage());
        }
    }
}
