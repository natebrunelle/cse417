Paste your code in p2-1.java. 

It will appear monospaced with the same exact 
spacing as in this source file.

Be sure to manually create line breaks, because
word wrap is not supported.