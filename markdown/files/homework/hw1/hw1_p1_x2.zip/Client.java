import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Client {
    public static String filename = "medium_unstable3.txt"; //change this file name to run a different test

    /*
     * This method reads the file indicated by the filename field.
     * It then builds the corresponding match object, and invokes both
     * of your getUnstablePair method as well as our stableAfterSwap (which
     * also invokes your getUnstablePair)
     */
    public static void main(String[] args){
        File input = new File(filename);
        try(Scanner inputReader = new Scanner(input)){
            int n = inputReader.nextInt();
            inputReader.nextLine();
            Proposer[] proposers = new Proposer[n];
            Receiver[] receivers = new Receiver[n];
            for(int i = 0; i < n; i++){
                proposers[i] = new Proposer(i);
                receivers[i] = new Receiver(i);
            }
            for(int i = 0; i < n; i++){
                String line = inputReader.nextLine();
                String[] list = line.split(" ");
                for(int j = 0; j < n; j++){
                    int receiverID = Integer.parseInt(list[j]);
                    proposers[i].addReceiver(receivers[receiverID]);
                }
            }
            for(int i = 0; i < n; i++){
                String line = inputReader.nextLine();
                String[] list = line.split(" ");
                for(int j = 0; j < n; j++){
                    int proposerID = Integer.parseInt(list[j]);
                    receivers[i].addProposer(proposers[proposerID]);
                }
            }
            Matching m = new Matching();
            for(int i = 0; i < n; i++){
                String line = inputReader.nextLine();
                String[] list = line.split(" ");
                int proposerID = Integer.parseInt(list[0]);
                int receiverID = Integer.parseInt(list[1]);
                Pair p = new Pair(proposers[proposerID], receivers[receiverID]);
                m.addPair(p);
            }
            System.out.println(m);
            System.out.println(StableChecker.getUnstablePair(m));
            // StableChecker.stableAfterSwap(m);
        } catch (FileNotFoundException e){
            e.printStackTrace();
        }
    }
}
