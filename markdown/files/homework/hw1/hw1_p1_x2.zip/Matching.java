import java.util.ArrayList;
import java.util.List;

public class Matching {
    /*
     * This class represents a matching, which is a collection of receiver-proposer ordered pairs.
     * For all tests we will run for this assignment, the matching will be perfect (meaning every
     * receiver and every proposer participate in exactly one pair).
     */

    private List<Pair> pairs;

    public Matching(){
        pairs = new ArrayList<>();
    }

    public Matching(List<Pair> pairs){
        this.pairs = pairs;
    }

    public void addPair(Pair p){
        pairs.add(p);
    }

    /*
     * returns a shallow copy of the list of Pairs.
     */
    public List<Pair> getPairs(){
        return new ArrayList<>(pairs);
    }

    public List<Proposer> getProposers(){
        List<Proposer> proposers = new ArrayList<>();
        for(Pair p : pairs){
            proposers.add(p.getProposer());
        }
        return proposers;
    }

    public List<Receiver> getReceivers(){
        List<Receiver> receivers = new ArrayList<>();
        for(Pair p : pairs){
            receivers.add(p.getReceiver());
        }
        return receivers;
    }

    public Proposer matchOfReceiver(Receiver r){
        for(Pair pair : pairs){
            if(pair.getReceiver().equals(r)){
                return pair.getProposer();
            }
        }
        return null; // this should never happen.
    }

    public Receiver matchOfProposer(Proposer p){
        for(Pair pair : pairs){
            if(pair.getProposer().equals(p)){
                return pair.getReceiver();
            }
        }
        return null; // this should never happen.
    }

    public String toString(){
        return pairs.toString();
    }

}
