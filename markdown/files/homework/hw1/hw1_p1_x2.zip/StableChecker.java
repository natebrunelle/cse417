import java.util.List;
import java.util.ArrayList;

public class StableChecker {

    /*
     * The input to this method is a matching.
     * If that matching is unstable, it should return an unstable pair (any such pair is fine)
     * If that matching is stable, it should return null;
     */
    public static Pair getUnstablePair(Matching m){
        return null;
    }

    /*
     * This method is meant to test potential counterexamples for the problem 1 claim.
     * To do this, it uses your code for getUnstablePair to check if the matching is stable.
     * It then builds new matchings by taking pairs of matches, swapping the receivers
     * and proposers in those matches, and checking if the resulting matching is unstable.
     */
    public static void stableAfterSwap(Matching m){
        if(getUnstablePair(m) == null){
            List<Pair> pairs = m.getPairs();
            List<Pair> oneSwap = new ArrayList<>(pairs);
            Boolean flag = false;
            for(int i = 0; i < pairs.size(); i++){
                Pair p1 = pairs.get(i);
                oneSwap.remove(p1);
                for(int j = i+1; j < pairs.size(); j++){
                    Pair p2 = pairs.get(j);
                    oneSwap.remove(p2);
                    Pair newp1 = new Pair(p1.getProposer(), p2.getReceiver());
                    Pair newp2 = new Pair(p2.getProposer(), p1.getReceiver());
                    oneSwap.add(newp1);
                    oneSwap.add(newp2);
                    if(!flag && getUnstablePair(new Matching(oneSwap)) == null && !flag){
                        System.out.println("This matching is still stable after swapping" + p1 + " and " + p2 + ": " + m);
                        flag = true;
                    }
                    oneSwap.add(p2);
                }
                oneSwap.add(p1);
            }
            if(!flag){
                System.out.println("This matching is not stable after swapping any matches: " + m);
            }
        }
        else{
            System.out.println("Matching is not stable: " + m);
        }
    }

}
