public class Pair {
    private final Proposer p;
    private final Receiver r;


    /*
     * This class represents a Proposer-receiver ordered pair. In class we called this thing a "Match".
     */
    public Pair(Proposer p, Receiver r){
        this.p = p;
        this.r = r;
    }

    public Proposer getProposer(){
        return p;
    }

    public Receiver getReceiver(){
        return r;
    }

    public String toString(){
        return "(" + p + ", " + r + ")";
    }

    public boolean equals(Object other){
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        Pair otherpair = (Pair) other;
        return otherpair.p.equals(this.p) &&  otherpair.r.equals(this.r);
    }
}
