import java.util.ArrayList;
import java.util.List;

/* This class represents a receiver in the Gale-Shapley algorithm */
public class Receiver {
    private int id;
    private List<Proposer> preferences;

    public Receiver(int id){
        this.id = id;
        this.preferences = new ArrayList<>();
    }

    public String toString(){
        return "Receiver " + id;
    }

    /* 
     * This method returns where the Proposer p appears in this
     * Receiver's preference list, where the "favorite" Proposer
     * appears at index 0.
     */
    public int getPreferenceOrder(Proposer p){
        return preferences.indexOf(p);
    }

    /*
     * Adds the given proposer p to the end of this receiver's preference list.
     * That is, p will be the least favorite of this receiver.
     */
    public void addProposer(Proposer p){
        preferences.add(p);
    }

    public void printPreferences(){
        System.out.println(preferences);
    }

    /* 
     * This method returns where this receiver prefers proposer p1 over proposer p2.
     */
    public boolean prefers(Proposer p1, Proposer p2){
        return getPreferenceOrder(p1) < getPreferenceOrder(p2);
    }

    public boolean equals(Object other){
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        Receiver otherr = (Receiver) other;
        return otherr.id == this.id;
    }
}
