import java.util.ArrayList;
import java.util.List;

/* This class represents a proposer in the Gale-Shapley algorithm */
public class Proposer {
    private int id;
    private List<Receiver> preferences;

    public Proposer(int id){
        this.id = id;
        this.preferences = new ArrayList<>();
    }

    public String toString(){
        return "Proposer " + id;
    }

    /* 
     * This method returns where the Receiver r appears in this
     * Proposer's preference list, where the "favorite" receiver
     * appears at index 0.
     */
    public int getPreferenceOrder(Receiver r){
        return preferences.indexOf(r);
    }

    /*
     * Adds the given receiver r to the end of this proposer's preference list.
     * That is, r will be the least favorite of this proposer.
     */
    public void addReceiver(Receiver r){
        preferences.add(r);
    }

    public void printPreferences(){
        System.out.println(preferences);
    }

    /* 
     * This method returns where this proposer prefers receiver r1 over receiver r2.
     */
    public boolean prefers(Receiver r1, Receiver r2){
        return getPreferenceOrder(r1) < getPreferenceOrder(r2);
    }

    public boolean equals(Object other){
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        Proposer otherp = (Proposer) other;
        return otherp.id == this.id;
    }
}
