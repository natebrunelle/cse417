import java.util.ArrayList;
import java.util.List;

public class BruteForce {
    public static List<PointPair> closePairs(List<CoordinatePair> points, double distance){
        List<PointPair> closePairs = new ArrayList<>();
        for(int i = 0; i < points.size(); i++){
            for(int j = i+1; j < points.size(); j++){
                CoordinatePair first = points.get(i);
                CoordinatePair second = points.get(j);
                if(first.distance(second) <= distance){
                    closePairs.add(new PointPair(first, second));
                }
            }
        }
        return closePairs;
    }
}
