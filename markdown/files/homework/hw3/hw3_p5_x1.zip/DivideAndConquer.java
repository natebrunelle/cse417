import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class DivideAndConquer {
    public static List<PointPair> closePairs(List<CoordinatePair> points, double distance, int c){
        List<PointPair> closePairs = new ArrayList<>();
        return closePairs;
    }

}
