import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Client {

    public static String fileToString(String filename){
        try{
            String data = new String(Files.readAllBytes(Paths.get(filename)));
            return data;
        }
        catch(IOException e){
            System.out.println(e);
        }
        return "";
    }
    
    public static void main(String[] args){
        // String text = fileToString("ATaleOfTwoCities.txt");
        // String text = fileToString("Pooh.txt");
        String text = "Hello World!";
        PrefixFreeEncoder encoder = new Huffman(text);
        encoder.printEncodingTable();
        String code = encoder.encode(text);
        System.out.println(code);
        System.out.println(encoder.decode(code));
    }
}
