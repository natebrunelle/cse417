import java.util.*;

public class Student extends PrefixFreeEncoder{

    public Student(String message){
        super(message);
    }

    public Student(int[] frequencies, char[] indexToChar){
        super(frequencies, indexToChar);
    }
    

    // This method populates an array called "encodingTable" using the
    // fields "frequencies" and "indexToChar".
    // Index i of the array encodingTable should have the code word
    // for the character that appears at index i of indexToChar
    // (and whose frequency appears at frequencies[i]).
    public void buildTable(){
        
    }

}
